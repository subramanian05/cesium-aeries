# Flight Map (MUI)

A Vite + React (JavaScript) + Material UI version of the SkySafe Flight Map screen. It runs on built-in sample data (made-up serials and tracks off the San Diego coast).

## Run

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production build in dist/
```

## What's included

| Area | Component |
| --- | --- |
| Top nav (links, Regions menu, Alerts badge, user menu with Auto/Dark/Light theme) | `TopNav.jsx` |
| Leaflet map with satellite/streets/dark base maps, flight tracks, drone and home markers, scale, right-click to copy coordinates | `FlightMap.jsx` |
| Floating controls: time filter pill, Search, Ruler, Settings, "N Flights" | `MapControls.jsx` |
| Detections list with expanded summary (Details / Focus) and CSV export | `DetectionsPanel.jsx` |
| Filters: time presets, affiliation, manufacturer, model include/exclude, height (MSL/HAT), weight | `FiltersPanel.jsx` |
| Flight Details: toolbar (summary, download, history, watch, playback, altitude, data table) and Identification / Classification / Flight Information / Data & Tracking sections | `FlightDetailsPanel.jsx` |
| Last Update card with deltas | `LastUpdateCard.jsx` |
| Altitude Profile chart (HAT/MSL) with a scrubber | `AltitudeProfile.jsx` |
| Search and Data Points dialogs | `Dialogs.jsx` |

Theme tokens are in `src/theme/theme.js`. Sample data comes from `src/data/flights.js`. To use real data, replace `generateFlights()` with an API call that returns the same shape (`{ model, manufacturer, serial, protocol, affiliation, home, points: [{ t, lat, lng, msl, hat, speed, rssi }], ... }`).

Screens narrower than the `md` breakpoint get a bottom-sheet layout.
