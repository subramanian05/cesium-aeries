import { createServer } from 'node:http';
import { WebSocketServer, WebSocket } from 'ws';
import { createDemo } from '../src/demo.js';
import { project, projectionDelta, validateSubscription } from '../src/projection.js';
import { keyOf } from '../src/telemetry.js';
export function createMockServer(port = 8080) {
  const http = createServer((request, response) => {
    response.setHeader('Access-Control-Allow-Origin', 'http://127.0.0.1:5173');
    response.setHeader('Content-Type', 'application/json');
    const url = new URL(request.url, 'http://localhost');
    if (url.pathname !== '/api/drone-details') { response.writeHead(404); response.end('{}'); return; }
    response.end(JSON.stringify({ provider: url.searchParams.get('provider'), sourceTrackId: url.searchParams.get('sourceTrackId'), description: 'Mock reference metadata; operational history is supplied by your Spring Boot API.', operator: 'Demonstration fleet', category: 'Simulated UAS', updatedAt: new Date().toISOString() }));
  });
  const ws = new WebSocketServer({ server: http, path: '/ws/drones', maxPayload: 16384 });
  ws.on('connection', socket => {
    const demo = createDemo(); let subscription = null, previous = { events: [] }, tick = 0;
    const send = message => {
      if (socket.readyState !== WebSocket.OPEN) return;
      if (socket.bufferedAmount > 4_000_000) { socket.close(1013, 'Client too slow'); return; }
      socket.send(JSON.stringify(message));
    };
    function projected(reset = false) {
      const result = project(demo.snapshot(), subscription);
      const previousTimes = new Map(previous.events.map(d => [keyOf(d), d.observedAt]));
      const events = reset ? result.events : result.events.filter(d => previousTimes.get(keyOf(d)) !== d.observedAt);
      send({ type: reset ? 'snapshot' : 'telemetry', subscriptionId: subscription?.subscriptionId, ...result, events, removed: reset ? [] : projectionDelta(previous, result) }); previous = result;
    }
    projected(true);
    socket.on('message', bytes => {
      try {
        const message = JSON.parse(bytes.toString());
        if (message.type !== 'subscribe') return;
        subscription = validateSubscription(message);
        send({ type: 'subscriptionAccepted', subscriptionId: subscription.subscriptionId }); projected(true);
      } catch { send({ type: 'error', message: 'Invalid subscription' }); }
    });
    const timer = setInterval(() => {
      const updates = demo.next(100);
      if (!subscription) send({ type: 'telemetry', events: updates });
      else if (++tick % 5 === 0) projected();
    }, 100);
    socket.on('close', () => clearInterval(timer));
  });
  http.listen(port, '127.0.0.1');
  return { http, ws, close: () => { for (const client of ws.clients) client.terminate(); ws.close(); http.close(); } };
}
if (process.argv[1]?.endsWith('/mock.js')) {
  const port = Number(process.env.PORT || 8080); createMockServer(port);
  console.log(`Mock feed: ws://localhost:${port}/ws/drones; REST: http://localhost:${port}/api/drone-details`);
}
