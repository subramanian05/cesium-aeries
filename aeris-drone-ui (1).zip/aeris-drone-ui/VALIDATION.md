# AERIS 2.0 validation

- `npm test`: 21 passing tests (11 Node integration/unit tests and 10 Vitest tests).
- Coverage: 5,000-track ingestion, worker-thread structured message exchange, acknowledgment flow control, 2,000-record batch limits, interpolation across longitude/heading wraparound, bounded prediction, eight-sample history, expiry and capacity, malformed frames, actual WebSocket reconnect, obsolete viewport subscription rejection, cluster-to-track changes and mock REST metadata.
- `npm run build`: successful production build, with a separate telemetry worker bundle and local Cesium assets.
- Runtime: Node 24.19.0, React 19.3.0, Cesium 1.145.0, Vite 8.3.0. Dependencies are locked in package-lock.json.
- Playwright desktop/interaction tests are included but were NOT executed successfully in this environment. The available browser could not access the local application during the original build, and local Chromium installation timed out. Visual rendering and GPU frame-rate performance remain unverified.
- 30 FPS is a rendering target. 1,000 observations/second is the demo generator target. Neither is a guarantee for every browser/GPU/backend combination.
- No live provider credentials or proprietary SkySafe/EnforceAir2 APIs were used.
