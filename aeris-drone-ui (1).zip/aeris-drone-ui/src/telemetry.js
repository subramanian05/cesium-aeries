export const MAX_TRACKS = 20000;
export const STALE_MS = 30000;
export const EXPIRE_MS = 120000;
export const keyOf = d => JSON.stringify([d.provider, d.feedId, d.sourceTrackId]);
const number = v => typeof v === 'number' && Number.isFinite(v);
export function normalize(input, now = Date.now()) {
  if (!input || typeof input !== 'object') throw Error('Observation must be an object');
  for (const field of ['provider', 'feedId', 'sourceTrackId']) {
    if (typeof input[field] !== 'string' || !input[field].trim() || input[field].length > 128) throw Error(`Invalid ${field}`);
  }
  const position = input.position;
  if (!position || !number(position.latitude) || !number(position.longitude) || Math.abs(position.latitude) > 90 || Math.abs(position.longitude) > 180) throw Error('Invalid coordinates');
  const time = typeof input.observedAt === 'string' ? Date.parse(input.observedAt) : NaN;
  if (!Number.isFinite(time) || time > now + 300000) throw Error('Invalid observation time');
  const altitude = position.altitudeMeters ?? null;
  const speed = input.motion?.groundSpeedMetersPerSecond ?? null;
  const heading = input.motion?.headingDegrees ?? null;
  if (altitude !== null && !number(altitude)) throw Error('Invalid altitude');
  if (speed !== null && (!number(speed) || speed < 0)) throw Error('Invalid speed');
  if (heading !== null && !number(heading)) throw Error('Invalid heading');
  const label = v => typeof v === 'string' ? v.slice(0, 128) : null;
  return { id: keyOf(input), provider: input.provider, feedId: input.feedId, sourceTrackId: input.sourceTrackId,
    observedAt: input.observedAt, time, receivedAt: now,
    latitude: position.latitude, longitude: position.longitude, altitude,
    altitudeReference: ['AGL', 'MSL', 'ELLIPSOID'].includes(position.altitudeReference) ? position.altitudeReference : 'UNKNOWN',
    speed, heading: heading === null ? null : ((heading % 360) + 360) % 360,
    sensorId: label(input.sensorId), model: label(input.identity?.model), serial: label(input.identity?.serialNumber),
    status: label(input.status) || 'TRACKING' };
}
export function matches(d, provider, query) {
  return (provider === 'ALL' || d.provider === provider) && (!query || `${d.provider} ${d.sourceTrackId} ${d.model || ''} ${d.serial || ''}`.toLowerCase().includes(query.toLowerCase()));
}
// Mutable latest-value cache deliberately stays out of React state.
export class TelemetryEngine {
  constructor({ maxTracks = MAX_TRACKS, now = () => Date.now() } = {}) {
    this.maxTracks = maxTracks; this.now = now; this.tracks = new Map(); this.history = new Map(); this.pending = new Map(); this.newPending = new Set(); this.listeners = new Set();
    this.stats = { received: 0, invalid: 0, outOfOrder: 0, coalesced: 0, capacityDropped: 0, expired: 0 };
  }
  subscribe(listener) { this.listeners.add(listener); return () => this.listeners.delete(listener); }
  emit(batch) { for (const listener of this.listeners) listener(batch); }
  ingest(input) {
    this.stats.received++;
    let d; try { d = normalize(input, this.now()); } catch { this.stats.invalid++; return false; }
    if (this.now() - d.time > EXPIRE_MS) { this.stats.expired++; return false; }
    const previous = this.pending.get(d.id) || this.tracks.get(d.id);
    if (previous && d.time <= previous.time) { this.stats.outOfOrder++; return false; }
    if (!previous && this.tracks.size + this.newPending.size >= this.maxTracks) {
      this.stats.capacityDropped++; return false;
    }
    if (this.pending.has(d.id)) this.stats.coalesced++;
    if (!this.tracks.has(d.id)) this.newPending.add(d.id);
    this.pending.set(d.id, d); return true;
  }
  flush(limit = 3000) {
    const updates = []; const removed = []; const now = this.now();
    for (const [id, d] of this.pending) {
      this.pending.delete(id); this.newPending.delete(id);
      if (now - d.time > EXPIRE_MS) continue;
      const history = this.history.get(id) || [];
      if (history.length && history.at(-1).altitudeReference !== d.altitudeReference) history.length = 0;
      history.push({ time: d.time, latitude: d.latitude, longitude: d.longitude, altitude: d.altitude, altitudeReference: d.altitudeReference, heading: d.heading, speed: d.speed });
      if (history.length > 8) history.shift();
      this.history.set(id, history);
      const track = { ...d, samples: history.slice() }; this.tracks.set(id, track); updates.push(track);
      if (updates.length >= limit) break;
    }
    for (const [id, d] of this.tracks) if (now - d.time > EXPIRE_MS) { this.tracks.delete(id); this.history.delete(id); removed.push(id); }
    if (updates.length || removed.length) this.emit({ updates, removed });
  }
  remove(ids) {
    const removed = [];
    for (const id of ids) { if (this.tracks.has(id) || this.pending.has(id)) removed.push(id); this.tracks.delete(id); this.history.delete(id); this.pending.delete(id); this.newPending.delete(id); }
    if (removed.length) this.emit({ updates: [], removed });
  }
  clear() { this.tracks.clear(); this.history.clear(); this.pending.clear(); this.newPending.clear(); this.stats = { received: 0, invalid: 0, outOfOrder: 0, coalesced: 0, capacityDropped: 0, expired: 0 }; this.emit({ reset: true, updates: [], removed: [] }); }
}
