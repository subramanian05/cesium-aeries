import { useRef } from 'react';
import { useVirtualizer } from '@tanstack/react-virtual';
import { Typography } from '@mui/material';
import { useUI } from './store';
import { STALE_MS } from './telemetry.js';
const fmt = v => v == null ? '—' : v.toLocaleString(undefined, { maximumFractionDigits: 1 });
export default function TrackList() {
  const rows = useUI(s => s.rows), selectedId = useUI(s => s.selectedId), select = useUI(s => s.select), lod = useUI(s => s.lod);
  const scroll = useRef();
  const virtual = useVirtualizer({ count: rows.length, getScrollElement: () => scroll.current, estimateSize: () => 56, overscan: 8, getItemKey: index => rows[index].id });
  return <section className="tracks-panel"><div className="track-heading"><Typography variant="subtitle2">Live tracks <span className="count-badge">{rows.length.toLocaleString()}</span></Typography><span className="hint">Only visible rows are rendered</span></div>
    <div className="virtual-scroll" ref={scroll} role="grid" aria-label="Live drone tracks" aria-rowcount={rows.length + 1} aria-colcount={7}>
      <div className="virtual-header virtual-columns" role="row">{['Track / provider','Model','Altitude','Speed','Heading','Observed UTC','State'].map(x => <div role="columnheader" key={x}>{x}</div>)}</div>
      {!rows.length && <p className="virtual-empty">{lod === 'clusters' ? 'Zoom into a cluster to inspect individual drones.' : 'No matching tracks. Check filters or connection.'}</p>}
      <div style={{ height: virtual.getTotalSize(), position: 'relative', minWidth: 840 }}>
        {virtual.getVirtualItems().map(item => {
          const d = rows[item.index], stale = Date.now() - d.time > STALE_MS;
          return <div role="row" aria-rowindex={item.index + 2} aria-selected={d.id === selectedId} key={item.key} tabIndex={0} className={`virtual-row virtual-columns ${d.id === selectedId ? 'selected' : ''}`}
            style={{ position: 'absolute', left: 0, top: 0, width: '100%', height: item.size, transform: `translateY(${item.start}px)` }}
            onClick={() => select(d.id)} onKeyDown={e => {
              if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); select(d.id); }
              if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); const next = Math.max(0,Math.min(rows.length-1,item.index+(e.key === 'ArrowDown'?1:-1))); virtual.scrollToIndex(next); requestAnimationFrame(() => scroll.current?.querySelector(`[aria-rowindex="${next+2}"]`)?.focus()); }
            }}>
            <div role="gridcell"><span className="track-id"><span className={`provider-dot ${d.provider === 'SKYSAFE' ? 'teal':'blue'}`}/>{d.sourceTrackId}</span><span className="subline">{d.provider} · {d.feedId}</span></div>
            <div role="gridcell">{d.model || 'Unknown'}</div><div role="gridcell">{fmt(d.altitude)} m <span className="muted">{d.altitudeReference}</span></div><div role="gridcell">{fmt(d.speed)} m/s</div><div role="gridcell">{fmt(d.heading)}°</div><div role="gridcell">{new Date(d.time).toISOString().slice(11,19)}</div><div role="gridcell" className={stale?'stale-text':'active-text'}>{stale?'Stale':'Active'}</div>
          </div>;
        })}
      </div>
    </div>
  </section>;
}
