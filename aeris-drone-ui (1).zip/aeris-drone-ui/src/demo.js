export function createDemo(count = 5000) {
  let seed = 42;
  const random = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
  const hubs = [[38.9, -77.1], [40.7, -74], [34.05, -118.24], [41.88, -87.63], [29.76, -95.37], [47.61, -122.33], [33.75, -84.39]];
  const drones = Array.from({ length: count }, (_, i) => {
    const [lat, lon] = hubs[i % hubs.length];
    return { schemaVersion: 1, provider: i % 2 ? 'ENFORCEAIR2' : 'SKYSAFE', feedId: `site-${i % 7 + 1}`, sourceTrackId: `UAS-${String(i + 1).padStart(5, '0')}`,
      observedAt: new Date().toISOString(), sensorId: `sensor-${i % 24 + 1}`,
      position: { latitude: lat + (random() - .5) * 4, longitude: lon + (random() - .5) * 5, altitudeMeters: 60 + random() * 240, altitudeReference: 'AGL' },
      motion: { groundSpeedMetersPerSecond: 5 + random() * 20, headingDegrees: random() * 360 },
      identity: { model: ['Mavic 3', 'Matrice 350', 'Autel EVO II', 'Unknown'][i % 4], serialNumber: `DEMO-${i + 1}` }, status: 'TRACKING' };
  });
  let cursor = 0; const times = new Float64Array(count).fill(Date.now());
  return { snapshot: () => structuredClone(drones), next(batchSize = 100) {
    const now = Date.now(); const batch = [];
    for (let j = 0; j < batchSize; j++) {
      const i = cursor++ % count; const d = drones[i]; const dt = Math.min(10, (now - times[i]) / 1000); times[i] = now;
      const h = d.motion.headingDegrees * Math.PI / 180;
      d.position.latitude += Math.cos(h) * d.motion.groundSpeedMetersPerSecond * dt / 111320;
      d.position.longitude += Math.sin(h) * d.motion.groundSpeedMetersPerSecond * dt / (111320 * Math.cos(d.position.latitude * Math.PI / 180));
      d.position.longitude = ((d.position.longitude + 540) % 360) - 180;
      d.observedAt = new Date(now).toISOString(); batch.push(structuredClone(d));
    }
    return batch;
  } };
}
