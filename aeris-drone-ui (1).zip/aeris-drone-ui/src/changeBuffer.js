// At most one worker batch in flight; changes coalesce while the UI is busy.
export class ChangeBuffer {
  constructor(send, chunkSize = 2000) { this.send = send; this.chunkSize = chunkSize; this.updates = new Map(); this.removed = new Set(); this.reset = false; this.clusters = undefined; this.inFlight = false; }
  add(batch) {
    if (batch.reset) { this.reset = true; this.updates.clear(); this.removed.clear(); this.clusters = []; }
    for (const id of batch.removed || []) { this.updates.delete(id); this.removed.add(id); }
    for (const d of batch.updates || []) { this.removed.delete(d.id); this.updates.set(d.id, d); }
    if (batch.clusters) this.clusters = batch.clusters;
    // A stalled main thread must not accumulate an unbounded list of old deletions.
    if (this.removed.size > 20000) this.onOverflow?.();
  }
  pump() {
    if (this.inFlight || (!this.reset && !this.updates.size && !this.removed.size && this.clusters === undefined)) return;
    const batch = { type: 'batch', reset: this.reset, updates: [], removed: [...this.removed] };
    for (const [id, d] of this.updates) { this.updates.delete(id); batch.updates.push(d); if (batch.updates.length === this.chunkSize) break; }
    if (this.clusters !== undefined) batch.clusters = this.clusters;
    this.reset = false; this.removed.clear(); this.clusters = undefined; this.inFlight = true; this.send(batch);
  }
  ack() { this.inFlight = false; this.pump(); }
}
