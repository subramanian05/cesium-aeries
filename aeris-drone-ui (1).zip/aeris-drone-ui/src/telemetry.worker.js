import { TelemetryEngine, keyOf } from './telemetry.js';
import { ChangeBuffer } from './changeBuffer.js';
import { createDemo } from './demo.js';
import { connectSocket } from './transport.js';
import { project, projectionDelta } from './projection.js';
export function createWorkerRuntime(send) {
  const engine = new TelemetryEngine();
  const buffer = new ChangeBuffer(send); let demo, stop = () => {}, timer, statsTimer, demoTick = 0, paused = false, subscription = null, previous = { events: [] }, meta = {};
  buffer.onOverflow = () => { buffer.add({ reset: true, updates: [...engine.tracks.values()] }); };
  engine.subscribe(batch => buffer.add(batch));
  let lastStatus;
  const status = connection => { if (connection !== lastStatus) { lastStatus = connection; send({ type: 'status', connection }); } };
  function projectDemo(reset = false) {
    const projection = project(demo.snapshot(), subscription);
    if (reset) engine.clear(); else engine.remove(projectionDelta(previous, projection));
    const previousTimes = new Map(previous.events.map(d => [keyOf(d), d.observedAt]));
    projection.events.filter(d => reset || previousTimes.get(keyOf(d)) !== d.observedAt).forEach(d => engine.ingest(d));
    buffer.add({ clusters: projection.clusters }); previous = projection; meta = { total: projection.total, truncated: projection.truncated };
  }
  function close() { stop(); clearInterval(timer); clearInterval(statsTimer); }
  function receive(message) {
    if (message.type === 'ack') { buffer.ack(); return; }
    if (message.type === 'pause') { paused = message.paused; return; }
    if (message.type === 'subscription') { subscription = message.subscription; if (demo) projectDemo(true); else stop.subscribe?.(subscription); return; }
    if (message.type !== 'start') return;
    close(); subscription = message.subscription; engine.clear(); demo = null;
    if (message.mode === 'demo') { demo = createDemo(); projectDemo(true); status('demo live'); }
    else {
      try { stop = connectSocket(message.url, { subscription, onEvents: events => events.forEach(d => engine.ingest(d)), onReset: () => engine.clear(), onStatus: status,
        onRemove: ids => engine.remove(ids), onClusters: clusters => buffer.add({ clusters }), onMeta: m => { meta = m; }, onInvalid: () => engine.stats.invalid++ }); }
      catch(e) { send({ type: 'error', message: e.message }); }
    }
    timer = setInterval(() => {
      if (demo && !paused) {
        const updates = demo.next(100);
        if (!subscription) updates.forEach(d => engine.ingest(d));
        else if (++demoTick % 5 === 0) projectDemo();
      }
      engine.flush(); buffer.pump();
    }, 100);
    statsTimer = setInterval(() => send({ type: 'stats', stats: { ...engine.stats, pending: engine.pending.size + buffer.updates.size, ...meta } }), 1000);
  }
  return { receive, close };
}
if (typeof self !== 'undefined' && typeof document === 'undefined') {
  const runtime = createWorkerRuntime(message => self.postMessage(message));
  self.onmessage = ({ data }) => runtime.receive(data);
}
