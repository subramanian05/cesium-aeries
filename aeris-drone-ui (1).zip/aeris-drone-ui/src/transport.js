export function connectSocket(url, { onEvents, onReset, onStatus, onInvalid, onRemove = () => {}, onClusters = () => {}, onMeta = () => {}, subscription = null }) {
  const parsed = new URL(url);
  if (!['ws:', 'wss:'].includes(parsed.protocol)) throw Error('Use a ws:// or wss:// endpoint');
  if (location.protocol === 'https:' && parsed.protocol !== 'wss:') throw Error('HTTPS pages require a secure wss:// endpoint');
  let socket, retryTimer, watchdog, stopped = false, attempt = 0, lastMessage = Date.now(), desired = subscription, ready = !subscription;
  function sendSubscription() { if (socket?.readyState === 1 && desired) { ready = false; socket.send(JSON.stringify({ type: 'subscribe', ...desired })); onStatus('subscribing'); } }
  function open() {
    if (stopped) return;
    onStatus('connecting'); lastMessage = Date.now();
    socket = new WebSocket(url);
    socket.onopen = () => { lastMessage = Date.now(); ready = !desired; onStatus('connected'); sendSubscription(); };
    socket.onmessage = ({ data }) => {
      if (stopped) return;
      lastMessage = Date.now();
      if (typeof data !== 'string' || data.length > 8_000_000) { onInvalid(); return; }
      try {
        const message = JSON.parse(data);
        if (message?.type === 'heartbeat') return;
        if (desired && message.subscriptionId !== desired.subscriptionId) return;
        if (message?.type === 'subscriptionAccepted') return;
        if (message?.type === 'error') { onStatus('server error'); return; }
        if (desired && !ready && message?.type !== 'snapshot') return;
        const events = Array.isArray(message) ? message : message?.events ?? (['remove','clusters'].includes(message?.type) ? [] : [message]);
        if (!Array.isArray(events) || events.length > 20000) throw Error('Invalid batch');
        if (message.removed && (!Array.isArray(message.removed) || message.removed.length > 20000 || !message.removed.every(x => typeof x === 'string' && x.length < 1024))) throw Error('Invalid removal');
        if (message.clusters && (!Array.isArray(message.clusters) || message.clusters.length > 2000 || !message.clusters.every(c => typeof c.id === 'string' && c.id.length < 128 && Number.isInteger(c.count) && c.count > 0 && Number.isFinite(c.latitude) && Math.abs(c.latitude) <= 90 && Number.isFinite(c.longitude) && Math.abs(c.longitude) <= 180 && Number.isFinite(c.cellDegrees) && c.cellDegrees > 0 && c.cellDegrees <= 30))) throw Error('Invalid clusters');
        if (message?.type === 'snapshot') { onReset(); ready = true; }
        onEvents(events);
        if (message.removed) onRemove(message.removed);
        if (message.clusters) onClusters(message.clusters);
        onMeta({ total: Number.isSafeInteger(message.total) ? message.total : undefined, truncated: !!message.truncated });
        attempt = 0; onStatus('connected');
      } catch { onInvalid(); }
    };
    socket.onerror = () => onStatus('connection error');
    socket.onclose = () => {
      clearInterval(watchdog);
      if (stopped) return;
      const delay = Math.min(30000, 1000 * 2 ** Math.min(attempt++, 5)) + Math.random() * 500;
      onStatus('reconnecting'); retryTimer = setTimeout(open, delay);
    };
    watchdog = setInterval(() => { if (Date.now() - lastMessage > 45000) socket.close(4000, 'Feed timeout'); }, 5000);
  }
  open();
  const stop = () => { stopped = true; clearTimeout(retryTimer); clearInterval(watchdog); if (socket) { socket.onclose = null; socket.onmessage = null; socket.onerror = null; socket.onopen = () => socket.close(); if (socket.readyState === 1) socket.close(); } };
  stop.subscribe = s => { desired = s; sendSubscription(); };
  return stop;
}
