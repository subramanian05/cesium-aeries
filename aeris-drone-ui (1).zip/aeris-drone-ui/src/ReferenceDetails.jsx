import { useQuery } from '@tanstack/react-query';
import { Alert, CircularProgress } from '@mui/material';
import { useUI } from './store';
export default function ReferenceDetails({ drone }) {
  const apiUrl = useUI(s => s.apiUrl), mode = useUI(s => s.mode);
  const query = useQuery({
    queryKey: ['drone-details', apiUrl, drone.provider, drone.feedId, drone.sourceTrackId],
    enabled: mode === 'websocket' && !!apiUrl,
    staleTime: 60000, gcTime: 300000, retry: 1,
    queryFn: async ({ signal }) => {
      const url = new URL(`${apiUrl.replace(/\/$/,'')}/api/drone-details`);
      url.search = new URLSearchParams({ provider: drone.provider, feedId: drone.feedId, sourceTrackId: drone.sourceTrackId }).toString();
      const response = await fetch(url, { signal, credentials: 'same-origin' });
      if (!response.ok) throw Error(`Details unavailable (${response.status})`);
      return response.json();
    }
  });
  if (mode !== 'websocket' || !apiUrl) return null;
  return <div className="reference-details"><span className="eyebrow">REFERENCE METADATA</span>{query.isFetching && <CircularProgress size={14} sx={{ mt: 1 }}/>} {query.error && <Alert severity="warning">{query.error.message}</Alert>}
    {query.data && <dl>{['operator','category','description'].map(k => <div key={k}><dt>{k}</dt><dd>{typeof query.data[k] === 'string' ? query.data[k] : 'Unavailable'}</dd></div>)}</dl>}
  </div>;
}
