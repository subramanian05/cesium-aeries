// Geographic interpolation with shortest-path longitude/heading, bounded prediction.
const wrap = x => ((x + 540) % 360) - 180;
const mix = (a, b, t) => a + (b - a) * t;
export function sampleMotion(track, displayTime, extrapolationMs = 1000, out = {}) {
  const samples = track.samples?.length ? track.samples : [track];
  const first = samples[0], last = samples.at(-1);
  Object.assign(out, last);
  if (displayTime <= first.time) return Object.assign(out, first, { motionState: 'buffering' });
  for (let i = 1; i < samples.length; i++) {
    const a = samples[i - 1], b = samples[i];
    if (displayTime <= b.time) {
      const fraction = (displayTime - a.time) / Math.max(1, b.time - a.time);
      out.latitude = mix(a.latitude, b.latitude, fraction);
      out.longitude = wrap(a.longitude + wrap(b.longitude - a.longitude) * fraction);
      out.heading = a.heading === null || b.heading === null ? b.heading : (a.heading + wrap(b.heading - a.heading) * fraction + 360) % 360;
      out.altitude = a.altitude === null || b.altitude === null ? b.altitude : mix(a.altitude, b.altitude, fraction);
      out.motionState = 'interpolated'; return out;
    }
  }
  const age = displayTime - last.time;
  const seconds = Math.min(age, Math.max(0, extrapolationMs)) / 1000;
  if (seconds > 0 && last.speed !== null && last.heading !== null) {
    const radius = 6371008.8, bearing = last.heading * Math.PI / 180;
    const lat = last.latitude * Math.PI / 180, lon = last.longitude * Math.PI / 180;
    const angle = last.speed * seconds / radius;
    const lat2 = Math.asin(Math.sin(lat) * Math.cos(angle) + Math.cos(lat) * Math.sin(angle) * Math.cos(bearing));
    const lon2 = lon + Math.atan2(Math.sin(bearing) * Math.sin(angle) * Math.cos(lat), Math.cos(angle) - Math.sin(lat) * Math.sin(lat2));
    out.latitude = lat2 * 180 / Math.PI; out.longitude = wrap(lon2 * 180 / Math.PI);
  }
  out.motionState = age <= extrapolationMs && last.speed !== null && last.heading !== null ? 'predicted' : 'held';
  return out;
}
