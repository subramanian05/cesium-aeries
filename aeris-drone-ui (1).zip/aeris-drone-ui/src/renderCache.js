export class RenderCache {
  constructor() { this.tracks = new Map(); this.clusters = new Map(); this.listeners = new Set(); }
  subscribe(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  apply(batch) {
    if (batch.reset) { this.tracks.clear(); this.clusters.clear(); }
    for (const id of batch.removed || []) this.tracks.delete(id);
    for (const d of batch.updates || []) this.tracks.set(d.id, d);
    if (batch.clusters) this.clusters = new Map(batch.clusters.map(c => [c.id,c]));
    for (const listener of this.listeners) listener(batch);
  }
  clear() { this.apply({ reset: true, updates: [], removed: [], clusters: [] }); }
}
