import { create } from 'zustand';
export const useUI = create(set => ({
  mode: 'demo', wsUrl: import.meta.env.VITE_WS_URL || 'ws://localhost:8080/ws/drones', apiUrl: import.meta.env.VITE_API_URL || '', viewportEnabled: false, viewport: null, subscriptionId: null, lod: 'tracks', interpolationDelayMs: 5500, extrapolationMs: 1000,  connection: 'starting', notice: '', provider: 'ALL', query: '', selectedId: null,
  focusRevision: 0, homeRevision: 0, paused: false, stats: { tracks: 0, stale: 0, rate: 0, pending: 0 }, rows: [], providers: [], selected: null,
  set: patch => set(patch),
  select: id => set(s => ({ selectedId: id, focusRevision: s.focusRevision + 1 })),
}));
