import { keyOf } from './telemetry.js';
export function inBounds(position, bounds) {
  if (!bounds) return true;
  const { latitude: lat, longitude: lon } = position;
  return lat >= bounds.south && lat <= bounds.north && (bounds.west <= bounds.east ? lon >= bounds.west && lon <= bounds.east : lon >= bounds.west || lon <= bounds.east);
}
export function validateSubscription(s) {
  if (!s || typeof s.subscriptionId !== 'string' || s.subscriptionId.length > 128 || !['tracks','clusters'].includes(s.lod)) throw Error('Invalid subscription');
  const b = s.bounds;
  if (b && (!['west','east','south','north'].every(k => Number.isFinite(b[k])) || Math.abs(b.west) > 180 || Math.abs(b.east) > 180 || Math.abs(b.south) > 90 || Math.abs(b.north) > 90 || b.south > b.north)) throw Error('Invalid bounds');
  return { ...s, maxTracks: Math.max(1, Math.min(10000, Number(s.maxTracks) || 10000)), cellDegrees: Math.max(.25, Math.min(30, Number(s.cellDegrees) || 5)) };
}
// Reference grid projection for demo/mock only. Production projector belongs in Java.
export function project(events, subscription) {
  if (!subscription) return { events, clusters: [], total: events.length, truncated: false };
  const s = validateSubscription(subscription);
  const filtered = events.filter(d => inBounds(d.position, s.bounds) && (!s.provider || s.provider === 'ALL' || d.provider === s.provider));
  if (s.lod === 'tracks') return { events: filtered.slice(0, s.maxTracks), clusters: [], total: filtered.length, truncated: filtered.length > s.maxTracks };
  const groups = new Map();
  for (const d of filtered) {
    const x = Math.floor((d.position.longitude + 180) / s.cellDegrees), y = Math.floor((d.position.latitude + 90) / s.cellDegrees), key = `${x}:${y}`;
    if (!groups.has(key)) groups.set(key, []); groups.get(key).push(d);
  }
  const clusters = []; const singles = [];
  for (const [id, group] of groups) {
    if (group.length === 1) { singles.push(group[0]); continue; }
    clusters.push({ id: `cluster:${id}`, count: group.length, latitude: group.reduce((n,d) => n + d.position.latitude, 0) / group.length, longitude: group.reduce((n,d) => n + d.position.longitude, 0) / group.length, cellDegrees: s.cellDegrees });
  }
  return { events: singles.slice(0, s.maxTracks), clusters: clusters.slice(0,2000), total: filtered.length, truncated: singles.length > s.maxTracks || clusters.length > 2000 };
}
export function projectionDelta(previous, next) {
  const ids = new Set(next.events.map(keyOf));
  return [...previous.events.map(keyOf)].filter(id => !ids.has(id));
}
