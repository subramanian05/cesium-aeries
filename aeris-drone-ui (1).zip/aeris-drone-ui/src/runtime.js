import { matches, STALE_MS } from './telemetry.js';
import { useUI } from './store';
import { RenderCache } from './renderCache.js';
export const engine = new RenderCache();
let worker, summaryTimer, uiSubscription, viewTimer, revision = 0, workerStats = {}, lastReceived = 0, lastSummary = Date.now();
export function summarize(updateRate = false) {
  const ui = useUI.getState(); const now = Date.now(); let stale = 0;
  const rows = []; const providers = new Set();
  for (const d of engine.tracks.values()) { providers.add(d.provider); if (now - d.time > STALE_MS) stale++; if (matches(d, ui.provider, ui.query)) rows.push(d); }
  rows.sort((a, b) => a.sourceTrackId.localeCompare(b.sourceTrackId));
  let rate = ui.stats.rate;
  if (updateRate) { rate = Math.max(0, Math.round(((workerStats.received || 0) - lastReceived) / Math.max(.001, (now - lastSummary) / 1000))); lastReceived = workerStats.received || 0; lastSummary = now; }
  const represented = engine.tracks.size + [...engine.clusters.values()].reduce((n,c) => n + c.count,0);
  useUI.setState({ rows, providers: [...new Set([...providers, 'SKYSAFE','ENFORCEAIR2'])].sort(), selected: engine.tracks.get(ui.selectedId) || null,
    stats: { ...workerStats, tracks: represented, individual: engine.tracks.size, clusters: engine.clusters.size, stale, pending: workerStats.pending || 0, rate } });
}
function desiredSubscription() {
  const ui = useUI.getState();
  if (!ui.viewportEnabled) return null;
  const v = ui.viewport;
  return { subscriptionId: String(++revision), bounds: v?.bounds || null, lod: v?.height > 2000000 ? 'clusters' : 'tracks', cellDegrees: v?.height > 7000000 ? 10 : 3, provider: ui.provider, maxTracks: 10000 };
}
export function updateViewport(viewport) { useUI.setState({ viewport }); }
function sendViewport() {
  clearTimeout(viewTimer); viewTimer = setTimeout(() => { const subscription = desiredSubscription(); if (subscription && worker) { useUI.setState({ subscriptionId: subscription.subscriptionId, lod: subscription.lod }); worker.postMessage({ type: 'subscription', subscription }); } }, 350);
}
export function switchFeed(mode, url = useUI.getState().wsUrl) {
  clearTimeout(viewTimer); worker?.terminate(); engine.clear(); workerStats = {}; lastReceived = 0; lastSummary = Date.now();
  useUI.setState({ mode, wsUrl: url, selectedId: null, selected: null, paused: false, notice: '', connection: 'starting', query: '' });
  const subscription = desiredSubscription();
  useUI.setState({ subscriptionId: subscription?.subscriptionId || null, lod: subscription?.lod || 'tracks' });
  try {
    const current = new Worker(new URL('./telemetry.worker.js', import.meta.url), { type: 'module' }); worker = current;
    current.onmessage = ({ data }) => {
      if (worker !== current) return;
      if (data.type === 'batch') { engine.apply(data); current.postMessage({ type: 'ack' }); }
      if (data.type === 'status' && useUI.getState().connection !== data.connection) useUI.setState({ connection: data.connection });
      if (data.type === 'stats') workerStats = data.stats;
      if (data.type === 'error') useUI.setState({ notice: data.message, connection: 'error' });
    };
    current.onerror = () => { useUI.setState({ notice: 'Telemetry worker failed. Check worker asset availability and browser console.', connection: 'error' }); current.terminate(); };
    current.postMessage({ type: 'start', mode, url, subscription });
  } catch(e) { useUI.setState({ notice: e.message, connection: 'error' }); }
  summarize();
}
export function startRuntime() {
  switchFeed('demo'); summaryTimer = setInterval(() => summarize(true), 1000);
  uiSubscription = useUI.subscribe((ui, prev) => {
    if (ui.paused !== prev.paused) worker?.postMessage({ type: 'pause', paused: ui.paused });
    if (ui.viewportEnabled !== prev.viewportEnabled) switchFeed(ui.mode);
    else if (ui.viewportEnabled && (ui.viewport !== prev.viewport || ui.provider !== prev.provider)) sendViewport();
  });
  return () => { worker?.terminate(); worker = undefined; clearTimeout(viewTimer); clearInterval(summaryTimer); uiSubscription?.(); engine.clear(); };
}
