import { createTheme } from '@mui/material/styles';
export const theme = createTheme({
  palette: { mode: 'dark', primary: { main: '#59dec8', contrastText: '#061b19' }, secondary: { main: '#83acff' },
    background: { default: '#09111c', paper: '#101c2b' }, text: { primary: '#ecf2f9', secondary: '#91a3b9' }, divider: '#243347' },
  typography: { fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif', button: { textTransform: 'none', fontWeight: 600 }, h6: { fontWeight: 650 } },
  shape: { borderRadius: 10 },
  components: { MuiButton: { defaultProps: { disableElevation: true } }, MuiTextField: { defaultProps: { size: 'small' } },
    MuiPaper: { styleOverrides: { root: { backgroundImage: 'none' } } }, MuiChip: { styleOverrides: { root: { fontSize: 11, height: 24, borderRadius: 6 } } },
    MuiTableCell: { styleOverrides: { root: { borderBottom: '1px solid #1b2b3d', padding: '11px 12px', whiteSpace: 'nowrap' }, head: { color: '#91a3b9', fontSize: 10, letterSpacing: 1, textTransform: 'uppercase', background: '#101c2b' } } } }
});
