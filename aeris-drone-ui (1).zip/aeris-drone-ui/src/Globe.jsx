import { useEffect, useRef, useState } from 'react';
import { Alert } from '@mui/material';
import { Viewer, ImageryLayer, TileMapServiceImageryProvider, buildModuleUrl, Color, Cartesian3, BillboardCollection, LabelCollection, PolylineCollection, ScreenSpaceEventHandler, ScreenSpaceEventType, Math as CMath, Rectangle, NearFarScalar, Cartesian2, LabelStyle } from 'cesium';
import 'cesium/Build/Cesium/Widgets/widgets.css';
import { engine, updateViewport } from './runtime';
import { sampleMotion } from './motion.js';
import { useUI } from './store';
import { matches, STALE_MS } from './telemetry';
const colors = { SKYSAFE: Color.fromCssColorString('#59dec8'), ENFORCEAIR2: Color.fromCssColorString('#83acff') };
const amber = Color.fromCssColorString('#ffc477');
const home = Rectangle.fromDegrees(-128, 22, -65, 52);
const coordinate = (d, result) => Cartesian3.fromDegrees(d.longitude, d.latitude, d.altitudeReference === 'ELLIPSOID' && d.altitude !== null ? d.altitude : 80, undefined, result);
function marker() {
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 48;
  const ctx = canvas.getContext('2d'); ctx.fillStyle = '#ffffff'; ctx.strokeStyle = '#06131d'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(24, 4); ctx.lineTo(40, 40); ctx.lineTo(24, 31); ctx.lineTo(8, 40); ctx.closePath(); ctx.fill(); ctx.stroke(); return canvas;
}
export default function Globe() {
  const ref = useRef(); const [error, setError] = useState('');
  useEffect(() => {
    let viewer;
    try {
      viewer = new Viewer(ref.current, { baseLayer: ImageryLayer.fromProviderAsync(TileMapServiceImageryProvider.fromUrl(buildModuleUrl('Assets/Textures/NaturalEarthII'))),
        baseLayerPicker: false, geocoder: false, homeButton: false, sceneModePicker: false, navigationHelpButton: false,
        animation: false, timeline: false, fullscreenButton: false, selectionIndicator: false, infoBox: false,
        requestRenderMode: true, maximumRenderTimeChange: Infinity, shouldAnimate: false });
    } catch (e) { setError(`Unable to initialize the 3D globe. Enable WebGL and hardware acceleration. ${e.message}`); return; }
    viewer.targetFrameRate = 30;
    viewer.scene.backgroundColor = Color.fromCssColorString('#070d17');
    viewer.scene.globe.baseColor = Color.fromCssColorString('#152e3e');
    viewer.scene.globe.enableLighting = false;
    viewer.scene.fog.enabled = true;
    viewer.scene.screenSpaceCameraController.minimumZoomDistance = 100;
    viewer.resolutionScale = Math.min(window.devicePixelRatio || 1, 1.5) / (window.devicePixelRatio || 1);
    viewer.camera.setView({ destination: home });
    const billboards = viewer.scene.primitives.add(new BillboardCollection({ scene: viewer.scene }));
    const clusterLabels = viewer.scene.primitives.add(new LabelCollection({ scene: viewer.scene }));
    const active = new Set();
    const labels = viewer.scene.primitives.add(new LabelCollection({ scene: viewer.scene }));
    const label = labels.add({ show: false, font: '13px sans-serif', fillColor: Color.WHITE, showBackground: true,
      backgroundColor: Color.fromCssColorString('#0b1725'), pixelOffset: new Cartesian2(0, -26), style: LabelStyle.FILL, disableDepthTestDistance: Number.POSITIVE_INFINITY });
    const lines = viewer.scene.primitives.add(new PolylineCollection());
    const trail = lines.add({ positions: [], width: 2, show: false }); trail.material.uniforms.color = amber;
    const glyph = marker(); const index = new Map(); const free = []; let trailId = null, trailPositions = [], lastTrailTime = 0;
    function redrawClusters() {
      clusterLabels.removeAll();
      for (const c of engine.clusters.values()) clusterLabels.add({ id: { cluster: c.id }, text: String(c.count), position: Cartesian3.fromDegrees(c.longitude,c.latitude,100), font: 'bold 16px sans-serif', showBackground: true, backgroundColor: Color.fromCssColorString('#1b665d'), backgroundPadding: new Cartesian2(10,8), fillColor: Color.WHITE });
    }
    function style(d, b, ui) {
      b.show = matches(d, ui.provider, ui.query);
      b.color = ui.selectedId === d.id ? amber : (Date.now() - d.time > STALE_MS ? Color.GRAY : colors[d.provider] || Color.WHITE);
      b.scale = ui.selectedId === d.id ? 1.5 : 1;
    }
    function updateSelection(ui) {
      const d = engine.tracks.get(ui.selectedId);
      if (trailId !== ui.selectedId) { trailId = ui.selectedId; trailPositions = []; lastTrailTime = 0; }
      label.show = !!d && matches(d, ui.provider, ui.query);
      if (d) {
        label.position = coordinate(d); label.text = d.sourceTrackId;
        if (d.time !== lastTrailTime) { trailPositions.push(coordinate(d)); if (trailPositions.length > 120) trailPositions.shift(); lastTrailTime = d.time; }
      }
      trail.show = label.show && trailPositions.length > 1;
      if (trail.show) trail.positions = trailPositions.slice();
    }
    function batch({ updates = [], removed = [], reset, clusters }) {
      const ui = useUI.getState();
      if (reset) { billboards.removeAll(); active.clear(); index.clear(); free.length = 0; trailPositions = []; lastTrailTime = 0; }
      if (reset || clusters) redrawClusters();
      for (const id of removed) { active.delete(id); const b = index.get(id); if (b) { b.show = false; b.id = undefined; free.push(b); index.delete(id); } }
      for (const d of updates) {
        let b = index.get(d.id);
        if (!b) { b = free.pop() || billboards.add({ image: glyph, width: 20, height: 20, alignedAxis: Cartesian3.UNIT_Z,
          scaleByDistance: new NearFarScalar(1000, 1.1, 18000000, .55) }); b.id = d.id; index.set(d.id, b); }
        active.add(d.id); b.position = coordinate(sampleMotion(d, Date.now() - ui.interpolationDelayMs, ui.extrapolationMs)); b.rotation = -CMath.toRadians(d.heading ?? 0); style(d, b, ui);
      }
      updateSelection(ui); viewer.scene.requestRender();
    }
    batch({ updates: [...engine.tracks.values()], removed: [], clusters: [...engine.clusters.values()] });
    const unsubscribe = engine.subscribe(batch);
    const framePosition = new Cartesian3(); const motion = {};
    const stopAnimation = viewer.scene.preUpdate.addEventListener(() => {
      if (document.hidden || !active.size) return;
      const ui = useUI.getState(); const now = Date.now(); let changed = false;
      for (const id of active) {
        const d = engine.tracks.get(id), b = index.get(id);
        if (!d || !b) { active.delete(id); continue; }
        if (now - d.time > STALE_MS) { active.delete(id); continue; }
        sampleMotion(d, now - ui.interpolationDelayMs, ui.extrapolationMs, motion);
        if (b.show) {
          b.position = coordinate(motion, framePosition); b.rotation = -CMath.toRadians(motion.heading ?? 0); changed = true;
          if (id === ui.selectedId) label.position = b.position;
        }
        if (motion.motionState === 'held') active.delete(id);
      }
      if (changed) viewer.scene.requestRender();
    });
    function publishViewport() {
      const rectangle = viewer.camera.computeViewRectangle(viewer.scene.globe.ellipsoid);
      updateViewport({ height: viewer.camera.positionCartographic.height, bounds: rectangle ? { west: CMath.toDegrees(rectangle.west), east: CMath.toDegrees(rectangle.east), south: CMath.toDegrees(rectangle.south), north: CMath.toDegrees(rectangle.north) } : null });
    }
    const stopCamera = viewer.camera.moveEnd.addEventListener(publishViewport); publishViewport();
    const uiUnsubscribe = useUI.subscribe((ui, prev) => {
      if (ui.provider !== prev.provider || ui.query !== prev.query || ui.selectedId !== prev.selectedId || ui.interpolationDelayMs !== prev.interpolationDelayMs || ui.extrapolationMs !== prev.extrapolationMs) {
        for (const [id, b] of index) { const d = engine.tracks.get(id); if (d) { style(d, b, ui); active.add(id); } }
        updateSelection(ui); viewer.scene.requestRender();
      }
      if (ui.focusRevision !== prev.focusRevision) {
        const d = engine.tracks.get(ui.selectedId);
        if (d) viewer.camera.flyTo({ destination: Cartesian3.fromDegrees(d.longitude, d.latitude, Math.max(6000, (d.altitude || 0) + 4000)), duration: 1.1 });
      }
      if (ui.homeRevision !== prev.homeRevision) viewer.camera.flyTo({ destination: home, duration: 1.2 });
    });
    const staleTimer = setInterval(() => {
      const ui = useUI.getState(); for (const [id, b] of index) { const d = engine.tracks.get(id); if (d) style(d, b, ui); }
      viewer.scene.requestRender();
    }, 1000);
    const handler = new ScreenSpaceEventHandler(viewer.scene.canvas);
    handler.setInputAction(click => { const picked = viewer.scene.pick(click.position); if (picked?.id?.cluster) { const c = engine.clusters.get(picked.id.cluster); if (c) viewer.camera.flyTo({ destination: Cartesian3.fromDegrees(c.longitude,c.latitude, Math.min(1500000, c.cellDegrees * 100000)), duration: 1 }); return; } if (typeof picked?.id === 'string' && engine.tracks.has(picked.id)) useUI.getState().select(picked.id); }, ScreenSpaceEventType.LEFT_CLICK);
    const observer = new ResizeObserver(() => { viewer.resize(); viewer.scene.requestRender(); }); observer.observe(ref.current);
    const removeError = viewer.scene.renderError.addEventListener((_scene, e) => setError(`Globe rendering stopped: ${e.message}`));
    return () => { observer.disconnect(); stopAnimation(); stopCamera(); clearInterval(staleTimer); unsubscribe(); uiUnsubscribe(); handler.destroy(); removeError(); viewer.destroy(); };
  }, []);
  return <div className="globe-container" ref={ref}>{error && <Alert severity="error" className="globe-error">{error}</Alert>}</div>;
}
