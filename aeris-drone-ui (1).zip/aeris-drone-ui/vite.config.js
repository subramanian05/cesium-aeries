import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { cpSync, mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
// Serve workers and local globe textures without a Cesium ion token or a CDN.
const destination = resolve('public/cesium');
mkdirSync(destination, { recursive: true });
for (const folder of ['Workers', 'Assets', 'Widgets', 'ThirdParty']) {
  cpSync(resolve('node_modules/cesium/Build/Cesium', folder), resolve(destination, folder), { recursive: true });
}
export default defineConfig({ plugins: [react()], base: './',
  define: { CESIUM_BASE_URL: JSON.stringify('./cesium/') },
  build: { chunkSizeWarningLimit: 5000 }, server: { port: 5173 }
});
