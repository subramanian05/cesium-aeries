# AERIS 2.0 — real-time drone operations UI

React + CesiumJS + Zustand + MUI, with a dedicated telemetry worker, bounded motion buffers, virtualized tracks, optional REST metadata and viewport subscriptions. JavaScript source is retained for continuity with version 1; modules are separated so TypeScript can be adopted independently.

## Start

Requires Node.js 22.12+.

```sh
npm ci
npm run dev
```

Open http://127.0.0.1:5173. Demo mode starts with 5,000 simulated drones and a target of 1,000 generated observations/second. No Cesium ion token is needed. Bundled Natural Earth imagery and Cesium assets are served locally. The ZIP also includes `dist/`, which any static HTTP server can serve without rebuilding; file:// loading will not work.

In another terminal:

```sh
npm run mock
```

In **Connection settings**, use `ws://127.0.0.1:8080/ws/drones`. Set optional REST base URL to `http://127.0.0.1:8080` to enable reference metadata. The mock backend is for local development only, bound to loopback, with no authentication.

```sh
npm test            # Node integration tests + Vitest architecture tests
npm run build       # production output with separate worker bundle
npm run preview
# Browser tests on a machine with Chromium available:
npx playwright install chromium
npm run test:e2e
```

The browser test configuration starts the Vite server and mock backend when they are not already running. A running older mock on port 8080 should be stopped first. Check `VALIDATION.md` for exactly which tests were executed here.

## What changed from version 1

- Parsing, validation, ordering, demo generation and native WebSocket run in a module Web Worker.
- One acknowledged worker batch at a time; at most 2,000 changed tracks per batch. Pending updates coalesce while the main thread is busy.
- Each track retains eight samples. The Cesium renderer interpolates at a configurable delayed display time and predicts only up to a bounded horizon, then holds position.
- Cesium animation targets 30 FPS. Dynamic primitives are updated directly, without React reconciliation per drone.
- TanStack Virtual replaces pagination with a scrollable list that mounts only visible rows plus overscan.
- TanStack Query retrieves optional REST reference metadata, with stable identity-based cache keys and request cancellation.
- Optional viewport subscriptions are debounced 350 ms after camera movement. Responses carry subscription IDs; obsolete responses and pre-snapshot deltas are ignored.
- Both in-browser demo and mock server implement grid clusters, cluster drill-down, provider filtering, viewport bounds and deletion when tracks leave the result.
- Added movement, worker flow-control, subscription-race, mock backend and browser tests.

## Data path

1. Spring Boot forwards connector-normalized observations from Kafka through an authenticated WebSocket endpoint.
2. Worker parses and validates JSON, rejects duplicate/older observations, bounds resident tracks, and stores recent samples.
3. Worker flushes every 100 ms, updating at most 3,000 pending tracks. It publishes changed tracks with recent samples in acknowledged batches of at most 2,000 records.
4. Main thread applies a batch to the imperative render cache and Cesium primitives, then acknowledges it.
5. Cesium evaluates bounded samples at display time and requests animation frames as necessary.
6. Once a second, summary snapshots reach Zustand and React/MUI. Selection and filters also use Zustand.

The browser never connects directly to Kafka. Cesium stays on the main thread; the worker owns ingestion. Full scenes are not copied every frame.

## Normalized observation

```json
{
  "schemaVersion": 1,
  "provider": "SKYSAFE",
  "feedId": "site-001",
  "sourceTrackId": "track-12345",
  "observedAt": "2026-09-12T12:00:00.123Z",
  "sensorId": "sensor-007",
  "position": {
    "latitude": 38.95,
    "longitude": -77.45,
    "altitudeMeters": 120.5,
    "altitudeReference": "AGL"
  },
  "motion": { "groundSpeedMetersPerSecond": 12.4, "headingDegrees": 245 },
  "identity": { "model": "Mavic 3", "serialNumber": "optional" },
  "status": "TRACKING"
}
```

Required: provider, feedId, sourceTrackId, observedAt, numeric latitude and longitude. Use ISO 8601 UTC timestamps with a Z suffix. Speed is m/s, heading degrees clockwise from geographic north, altitude meters. Optional fields may be absent. Each record is a complete observation, not a JSON patch. Unknown values remain unavailable.

Identity is `JSON.stringify([provider, feedId, sourceTrackId])`, avoiding ambiguous concatenation. These are provider tracks, not fused physical aircraft. Equal or earlier timestamps are ignored; extend ordering with a sequence number if distinct observations share a timestamp. History is kept across updates but reset when the altitude reference changes.

## Legacy WebSocket mode (default)

**Viewport & clusters is OFF by default**, so no subscription messages are sent to an existing plain-JSON backend.

Supported text frames:

```js
observation
[observation1, observation2]
{ type: 'telemetry', events: [observation1, observation2] }
{ type: 'snapshot', events: [/* complete replacement */] }
{ type: 'remove', removed: ['["SKYSAFE","site-001","track-12345"]'] }
{ type: 'heartbeat' }
```

A snapshot atomically starts a replacement of the main-thread scene (delivered in bounded chunks). It must contain the complete subscribed result in one input frame, limited to 20,000 observations and 8 million string code units. Do not send each page as an independent snapshot. For larger scenes, implement begin/page/end snapshot assembly and watermark reconciliation in the protocol.

Reconnect uses exponential delay with jitter, approximately 1–30 seconds. Send heartbeats at least every 15 seconds on quiet feeds; the client reconnects after 45 seconds of silence. Reconnect should produce a fresh snapshot. STOMP, SockJS and binary framing are not implemented.

## Viewport subscription protocol (opt-in)

Enable **Viewport & clusters** only if the backend implements this contract. Both included demos support it. Changing this toggle restarts the feed; camera/provider changes send a debounced new subscription. Search remains a local search over loaded individual tracks; it does not search cluster members or unloaded tracks.

Client → server:

```json
{
  "type": "subscribe",
  "subscriptionId": "42",
  "bounds": { "west": -100, "south": 25, "east": -65, "north": 50 },
  "lod": "clusters",
  "cellDegrees": 3,
  "provider": "ALL",
  "maxTracks": 10000
}
```

- Bounds are degrees. `west > east` means the viewport crosses the antimeridian. Null bounds mean global coverage.
- `lod` is `clusters` above 2,000 km camera height and `tracks` below it. This is a starting policy, not a universal optimal threshold.
- The grid size is 10 degrees above 7,000 km and 3 degrees otherwise. Production should select a suitable geographic index and grid policy.
- Provider is a named provider or ALL. Subscriptions must be authorized by the server.

Server → client:

```js
{ type: 'subscriptionAccepted', subscriptionId: '42' }
{
  type: 'snapshot', subscriptionId: '42',
  events: [/* singleton or individual observations */],
  clusters: [
    { id: 'cluster:27:42', latitude: 38.9, longitude: -77.1, count: 231, cellDegrees: 3 }
  ],
  total: 5000, truncated: false
}
{
  type: 'telemetry', subscriptionId: '42',
  events: [/* changed observations */],
  removed: [/* encoded provider-track keys that left this result */],
  clusters: [/* complete current cluster list, NOT a delta */],
  total: 5000, truncated: false
}
```

Acceptance is informational: only the current subscription's snapshot unlocks its deltas. The client discards messages tagged with old IDs, including delayed snapshots. The server must order snapshot before deltas for a subscription. Restarted sockets resend the desired subscription and await its snapshot. The old displayed scene remains until that snapshot arrives; age/stale indicators continue to apply.

Cluster counts and individual observations must be disjoint. `total` counts all authorized matches before display caps. `truncated` must be true if the server omitted matches. The UI caps clusters at 2,000 and individual subscriptions at 10,000. Click a cluster to zoom in and request individual tracks.

The reference mock groups current positions into a simple latitude/longitude grid and recomputes projections at 2 Hz. It sends only changed individual observations, complete cluster lists, and removals. This demonstrates the contract, not a production clustering algorithm. Implement the equivalent Java/Spring service against your Kafka-backed latest-state/cluster read model.

## Motion and correctness

Controls:

| Setting | Default | Behavior |
|---|---:|---|
| Display delay | 5.5 seconds | Interpolate at wall clock minus this delay |
| Prediction limit | 1 second | Continue briefly using ground speed/heading, then hold |
| Render target | 30 FPS | Target; actual GPU/browser performance varies |
| Samples per track | 8 | Bounded recent history |
| Stale age | 30 seconds | Based on newest observedAt, not delayed display time |
| Expiry | 120 seconds | Remove old tracks and samples |
| Track capacity | 20,000 | Reject new identities at capacity; existing tracks update |

The delay matches the demo's roughly 5-second per-track update interval. Tune it to actual source cadence and jitter. A short delay on a sparse feed will produce brief prediction followed by held positions; a longer delay produces smoother motion at the cost of latency. No configuration creates new observations.

Longitude and heading interpolation use the shortest wraparound path. Prediction follows a spherical destination calculation and is capped; it does not continue indefinitely. New predictions stop when stale. Histories are bounded and cleared on replacement snapshots. Details show the newest received telemetry, whereas the map uses delayed motion; selected trails show received observations and can extend ahead of the delayed marker.

The globe uses an ellipsoid surface. Only ELLIPSOID altitudes position drones at their reported 3D height. AGL, MSL and unknown references use an 80 m display offset above the ellipsoid, while preserving the reported altitude in details. Accurate AGL needs terrain and MSL needs geoid conversion.

## Optional REST details

Set `VITE_API_URL` or the REST base URL field. The UI requests:

```http
GET /api/drone-details?provider=SKYSAFE&feedId=site-001&sourceTrackId=track-12345
```

```json
{ "operator": "Example", "category": "UAS", "description": "Reference information" }
```

Reference requests are disabled in demo mode and when the URL is empty. TanStack Query caches per endpoint/provider/feed/track for 60 seconds and garbage-collects unused entries after five minutes. Live position updates do not invalidate this metadata cache. REST fetch uses same-origin credentials; deploy under a common origin or deliberately adapt credential/CORS handling to your authentication system. The local mock permits the default Vite origin.

## Production integration

- Authenticate the WebSocket handshake; validate Origin and authorization for every subscription. The browser cannot attach arbitrary Authorization headers. Prefer an established session or deliberately designed short-lived ticket flow. Do not place permanent secrets in URLs or Vite configuration.
- Use wss:// under HTTPS. Configure reverse proxy WebSocket upgrade and idle timeout.
- Serve all of dist/, including `cesium/` and `assets/telemetry.worker-*.js`. Allow same-origin module workers in CSP (`worker-src 'self'`), with Cesium-specific worker requirements reviewed for your deployment.
- Browser WebSocket still has no inbound backpressure. The worker acknowledgment protocol bounds worker→UI delivery, not the browser's socket buffer. Backend per-client output caps, coalescing and snapshot recovery remain necessary.
- Render full history only on request, from your backend; never accumulate every event in the browser.
- Benchmark target hardware with realistic marker density, labels, motion, payload size, source intervals and viewport changes. Prefer billboards for thousands of drones; selected-only labels/trails avoid unnecessary geometry.
- Use a few collections, shared textures, reusable objects and explicit Cesium cleanup. An idle scene need not render continuously; an actively interpolating scene does request frames.
- Stored provider samples are examples, not verified proprietary SkySafe or EnforceAir2 schemas.

## Files

| Module | Purpose |
|---|---|
| src/telemetry.worker.js | Background ingestion and batching |
| src/telemetry.js | Validation, latest state and sample history |
| src/changeBuffer.js | Bounded acknowledged worker delivery |
| src/transport.js | Reconnect, frame decoding and subscription IDs |
| src/projection.js | Shared demo/reference viewport projection |
| src/motion.js | Interpolation and bounded prediction |
| src/runtime.js, src/renderCache.js | Worker lifecycle, imperative cache and UI summaries |
| src/Globe.jsx | Cesium primitives, animation and camera subscriptions |
| src/store.js | Zustand UI state |
| src/TrackList.jsx | TanStack Virtual track grid |
| src/ReferenceDetails.jsx | TanStack Query REST metadata |
| src/App.jsx, src/theme.js, src/styles.css | MUI application shell |
| server/mock.js | Native WebSocket and REST reference backend |
| tests/ | Unit, integration, worker and optional browser tests |

References: [Cesium collections](https://cesium.com/learn/cesiumjs/ref-doc/BillboardCollection.html), [Zustand](https://zustand.docs.pmnd.rs/), [TanStack Virtual](https://tanstack.com/virtual/latest/docs/introduction), [TanStack Query](https://tanstack.com/query/latest), [MUI](https://mui.com/material-ui/customization/theming/).
