import test from 'node:test';
import assert from 'node:assert/strict';
import { WebSocketServer } from 'ws';
import { connectSocket } from '../src/transport.js';
import { TelemetryEngine } from '../src/telemetry.js';
import { createDemo } from '../src/demo.js';
// Browser native WebSocket is also available in Node 22+.
globalThis.location = { protocol: 'http:' };
const until = async (predicate, timeout = 6000) => {
  const started = Date.now();
  while (!predicate()) { if (Date.now() - started > timeout) throw Error('Condition timed out'); await new Promise(resolve => setTimeout(resolve, 20)); }
};
test('actual socket snapshot, 1,000-event batch, invalid frame and reconnection', async () => {
  const server = new WebSocketServer({ port: 0, host: '127.0.0.1' });
  await new Promise(resolve => server.once('listening', resolve));
  const engine = new TelemetryEngine(); let connections = 0, snapshots = 0, invalid = 0, statuses = [];
  server.on('connection', socket => {
    connections++; const demo = createDemo();
    socket.send(JSON.stringify({ type: 'snapshot', events: demo.snapshot() }));
    const timer = setTimeout(() => {
      if (socket.readyState !== 1) return;
      socket.send(JSON.stringify({ type: 'telemetry', events: demo.next(1000) }));
      socket.send('invalid json');
      socket.send(JSON.stringify({ type: 'heartbeat' }));
    }, 30);
    socket.on('close', () => clearTimeout(timer));
  });
  const stop = connectSocket(`ws://127.0.0.1:${server.address().port}`, {
    onEvents: events => { events.forEach(d => engine.ingest(d)); engine.flush(20000); },
    onReset: () => { snapshots++; engine.clear(); }, onStatus: status => statuses.push(status), onInvalid: () => invalid++
  });
  try {
    await until(() => engine.stats.received === 6000 && invalid === 1);
    assert.equal(engine.tracks.size, 5000); assert.equal(snapshots, 1);
    for (const socket of server.clients) socket.close(1012, 'Test restart');
    await until(() => connections === 2 && snapshots === 2);
    assert(statuses.includes('reconnecting')); assert.equal(engine.tracks.size, 5000);
  } finally {
    stop(); for (const socket of server.clients) socket.terminate();
    await new Promise(resolve => server.close(resolve));
  }
});
test('invalid scheme is rejected before opening a connection', () => {
  assert.throws(() => connectSocket('https://example.test', {}), /ws:\/\//);
});
test('ignores superseded subscription snapshots and waits for current snapshot', async () => {
  const server = new WebSocketServer({port:0,host:'127.0.0.1'});
  await new Promise(resolve => server.once('listening',resolve));
  let subscriptions=0,resets=0,seen=[];
  server.on('connection',socket=>socket.on('message',bytes=>{
    const sub=JSON.parse(bytes);subscriptions++;
    if(sub.subscriptionId==='1') return;
    socket.send(JSON.stringify({type:'snapshot',subscriptionId:'1',events:[{marker:'obsolete'}]}));
    socket.send(JSON.stringify({type:'telemetry',subscriptionId:'2',events:[{marker:'before-snapshot'}]}));
    socket.send(JSON.stringify({type:'snapshot',subscriptionId:'2',events:[{marker:'current'}]}));
  }));
  const stop=connectSocket(`ws://127.0.0.1:${server.address().port}`,{subscription:{subscriptionId:'1',lod:'tracks'},onEvents:events=>seen.push(...events),onReset:()=>resets++,onStatus:()=>{},onInvalid:()=>{}});
  try{await until(()=>subscriptions===1);stop.subscribe({subscriptionId:'2',lod:'tracks'});await until(()=>seen.length===1);assert.deepEqual(seen,[{marker:'current'}]);assert.equal(resets,1);}
  finally{stop();for(const socket of server.clients)socket.terminate();await new Promise(resolve=>server.close(resolve));}
});
