import { describe, it, expect } from 'vitest';
import { sampleMotion } from '../src/motion.js';
import { ChangeBuffer } from '../src/changeBuffer.js';
import { project, inBounds, projectionDelta } from '../src/projection.js';
import { TelemetryEngine } from '../src/telemetry.js';
const point = (time,longitude,heading=0) => ({time,longitude,latitude:0,heading,speed:10,altitude:100,altitudeReference:'ELLIPSOID'});
describe('bounded movement', () => {
 it('interpolates across dateline and heading zero without a long rotation', () => {
  const out = sampleMotion({samples:[point(0,179,350),point(1000,-179,10)]},500);
  expect(Math.abs(out.longitude)).toBe(180); expect(out.heading).toBe(0); expect(out.motionState).toBe('interpolated');
 });
 it('holds the same capped predicted position after extrapolation expires', () => {
  const track={samples:[point(1000,0,90)]};
  expect(sampleMotion(track,2000,1000).longitude).toBeCloseTo(sampleMotion(track,9000,1000).longitude,10);
  expect(sampleMotion(track,9000,1000).motionState).toBe('held');
  expect(sampleMotion(track,2000,0).longitude).toBe(0);
 });
 it('does not predict motion without speed or heading', () => {
  expect(sampleMotion({samples:[{...point(1000,5),speed:null}]},1500).longitude).toBe(5);
 });
 it('retains only eight motion samples per track and cleans them up', () => {
  const now=Date.now(), e=new TelemetryEngine({now:()=>now+100});
  for(let i=0;i<20;i++){e.ingest({provider:'p',feedId:'f',sourceTrackId:'t',observedAt:new Date(now+i).toISOString(),position:{latitude:0,longitude:0}});e.flush();}
  expect([...e.tracks.values()][0].samples).toHaveLength(8);e.remove([...e.tracks.keys()]);expect(e.history.size).toBe(0);
 });
});
describe('worker delivery', () => {
 it('allows one in-flight message and coalesces pending updates', () => {
  const sent=[];const b=new ChangeBuffer(message=>sent.push(message),2);
  b.add({updates:[{id:'a',value:1}]});b.pump();
  for(let i=2;i<100;i++){b.add({updates:[{id:'a',value:i}]});b.pump();}
  expect(sent).toHaveLength(1);expect(b.updates.size).toBe(1);b.ack();expect(sent[1].updates[0].value).toBe(99);
 });
 it('orders reset after the outstanding batch and drops obsolete queued work', () => {
  const sent=[];const b=new ChangeBuffer(x=>sent.push(x));b.add({updates:[{id:'old'}]});b.pump();
  b.add({updates:[{id:'obsolete'}]});b.add({reset:true,updates:[{id:'new'}]});b.ack();
  expect(sent[1].reset).toBe(true);expect(sent[1].updates.map(x=>x.id)).toEqual(['new']);
 });
 it('chunks a 5,000-track snapshot without losing entries', () => {
  const sent=[];const b=new ChangeBuffer(x=>sent.push(x));b.add({reset:true,updates:Array.from({length:5000},(_,i)=>({id:String(i)}))});b.pump();b.ack();b.ack();
  expect(sent.map(x=>x.updates.length)).toEqual([2000,2000,1000]);expect(sent.filter(x=>x.reset)).toHaveLength(1);
 });
});
describe('viewport projection', () => {
 const events=Array.from({length:100},(_,i)=>({provider:i%2?'A':'B',feedId:'f',sourceTrackId:String(i),position:{latitude:10,longitude:10+i*.001}}));
 it('supports a viewport crossing the dateline', () => {
  const bounds={west:170,east:-170,south:-20,north:20};expect(inBounds({latitude:0,longitude:179},bounds)).toBe(true);expect(inBounds({latitude:0,longitude:0},bounds)).toBe(false);
 });
 it('preserves count and filters providers in cluster mode', () => {
  const result=project(events,{subscriptionId:'1',lod:'clusters',provider:'A',cellDegrees:3});
  expect(result.total).toBe(50);expect(result.clusters.reduce((n,c)=>n+c.count,0)+result.events.length).toBe(50);
 });
 it('caps individual tracks and explicitly reports truncation and removals', () => {
  const result=project(events,{subscriptionId:'2',lod:'tracks',maxTracks:10});expect(result.events).toHaveLength(10);expect(result.truncated).toBe(true);expect(projectionDelta({events},result)).toHaveLength(90);
 });
});
