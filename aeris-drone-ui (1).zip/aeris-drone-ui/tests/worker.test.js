import test from 'node:test';
import assert from 'node:assert/strict';
import { Worker } from 'node:worker_threads';
test('worker batches demo tracks, waits for acknowledgment and switches to clusters', async () => {
  const url = new URL('../src/telemetry.worker.js', import.meta.url).href;
  const source = `import { parentPort } from 'node:worker_threads'; import { createWorkerRuntime } from ${JSON.stringify(url)}; const runtime=createWorkerRuntime(data=>parentPort.postMessage(data)); parentPort.on('message',message=>runtime.receive(message));`;
  const worker = new Worker(new URL(`data:text/javascript,${encodeURIComponent(source)}`));
  const batches = []; let automaticAck = false;
  worker.on('message', message => { if(message.type==='batch'){batches.push(message);if(automaticAck)worker.postMessage({type:'ack'});} });
  const until = async condition => { const start=Date.now();while(!condition()){if(Date.now()-start>5000)throw Error('Worker timed out');await new Promise(r=>setTimeout(r,20));} };
  try {
    worker.postMessage({type:'start',mode:'demo'});
    await until(()=>batches.length===1);
    await new Promise(r=>setTimeout(r,350));assert.equal(batches.length,1);
    automaticAck=true;worker.postMessage({type:'ack'});
    await until(()=>new Set(batches.flatMap(b=>b.updates.map(d=>d.id))).size===5000);
    assert(batches.every(b=>b.updates.length<=2000));
    const before=batches.length;
    worker.postMessage({type:'subscription',subscription:{subscriptionId:'1',lod:'clusters',cellDegrees:10,maxTracks:10000}});
    await until(()=>batches.slice(before).some(b=>b.reset&&b.clusters?.length));
    const latest=batches.slice(before).find(b=>b.reset&&b.clusters?.length);
    assert.equal(latest.clusters.reduce((n,c)=>n+c.count,0)+latest.updates.length,5000);
  } finally { await worker.terminate(); }
});
