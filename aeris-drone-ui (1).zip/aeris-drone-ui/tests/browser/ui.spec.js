import { test, expect } from '@playwright/test';
test('demo, virtualized list, selection, motion settings and cluster mode', async ({page}) => {
  const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('/');
  await expect(page.locator('.count-badge')).toHaveText('5,000');
  await expect(page.locator('.virtual-row')).not.toHaveCount(0);
  expect(await page.locator('.virtual-row').count()).toBeLessThan(40);
  await page.getByLabel('Search tracks').fill('UAS-00001');
  await expect(page.locator('.virtual-row')).toHaveCount(1);
  await page.locator('.virtual-row').click();
  await expect(page.getByRole('heading',{name:'UAS-00001'})).toBeVisible();
  await page.getByRole('button',{name:'Reset view'}).click();
  await page.getByLabel('Viewport & clusters').check();
  await expect(page.getByText('Viewport subscription active')).toBeVisible();
  await expect(page.locator('.metric-value').filter({hasText:'Clusters'})).toBeVisible();
  await expect(page.locator('.globe-error')).toHaveCount(0);
  expect(errors).toEqual([]);
  await page.screenshot({path:'test-results/aeris-desktop.png',fullPage:true});
});
test('mock websocket and REST reference details', async ({page})=>{
  await page.goto('/');await page.getByRole('button',{name:'Connection settings'}).click();
  await page.getByLabel('WebSocket endpoint').fill('ws://127.0.0.1:8080/ws/drones');
  await page.getByLabel('Optional REST API base URL').fill('http://127.0.0.1:8080');
  await page.getByRole('button',{name:'Connect to backend'}).click();
  await expect(page.locator('.count-badge')).toHaveText('5,000');
  await page.getByLabel('Search tracks').fill('UAS-00001');await page.locator('.virtual-row').click();
  await expect(page.getByText('Demonstration fleet')).toBeVisible();
});
