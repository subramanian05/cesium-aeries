import test from 'node:test';
import assert from 'node:assert/strict';
import { TelemetryEngine, normalize, keyOf, EXPIRE_MS } from '../src/telemetry.js';
import { createDemo } from '../src/demo.js';
const now = Date.parse('2026-09-12T12:00:00Z');
const observation = (id = 'one', delta = 0) => ({ provider: 'SKYSAFE', feedId: 's1', sourceTrackId: id, observedAt: new Date(now + delta).toISOString(), position: { latitude: 38, longitude: -77, altitudeMeters: 123, altitudeReference: 'AGL' }, motion: { headingDegrees: 370, groundSpeedMetersPerSecond: 10 } });
test('normalizes heading, retains altitude reference, rejects invalid coordinates', () => {
  assert.equal(normalize(observation(), now).heading, 10);
  assert.equal(normalize(observation(), now).altitudeReference, 'AGL');
  const d = observation(); d.position.latitude = 95; assert.throws(() => normalize(d, now));
  d.position.latitude = '38'; assert.throws(() => normalize(d, now));
});
test('coalesces newer events and rejects duplicate/out-of-order updates', () => {
  const e = new TelemetryEngine({ now: () => now + 100 });
  e.ingest(observation()); e.ingest(observation('one', 50)); e.ingest(observation('one', 20)); e.ingest(observation('one', 50)); e.flush();
  assert.equal(e.tracks.size, 1); assert.equal(e.tracks.values().next().value.time, now + 50);
  assert.equal(e.stats.coalesced, 1); assert.equal(e.stats.outOfOrder, 2);
});
test('bounded capacity allows updates to existing tracks; expiration frees capacity', () => {
  let time = now; const e = new TelemetryEngine({ maxTracks: 2, now: () => time });
  e.ingest(observation('a')); e.ingest(observation('b')); assert.equal(e.ingest(observation('c')), false);
  e.flush(1); assert.equal(e.ingest(observation('a', 1)), true); e.flush(); assert.equal(e.tracks.size, 2);
  time += EXPIRE_MS + 10; e.flush(); assert.equal(e.tracks.size, 0);
  assert.equal(e.ingest(observation('c', EXPIRE_MS + 10)), true);
});
test('source identity is collision safe and includes provider/feed', () => {
  assert.notEqual(keyOf(observation()), keyOf({ ...observation(), provider: 'ENFORCEAIR2' }));
  assert.notEqual(keyOf({ provider:'a:b',feedId:'c',sourceTrackId:'d' }), keyOf({ provider:'a',feedId:'b:c',sourceTrackId:'d' }));
});
test('5,000-track snapshot and burst remain bounded and flush incrementally', () => {
  const e = new TelemetryEngine(); const demo = createDemo();
  demo.snapshot().forEach(d => e.ingest(d)); assert.equal(e.pending.size, 5000);
  e.flush(3000); assert.equal(e.tracks.size, 3000); e.flush(); assert.equal(e.tracks.size, 5000);
  demo.next(5000).forEach(d => e.ingest(d)); e.flush(); e.flush(); assert.equal(e.tracks.size, 5000);
  e.clear(); assert.equal(e.newPending.size, 0); assert.equal(e.tracks.size, 0);
});
test('rejects historical and far-future events without consuming capacity', () => {
  const e = new TelemetryEngine({ now: () => now });
  e.ingest(observation('old', -EXPIRE_MS - 1)); e.ingest(observation('future', 300001));
  assert.equal(e.pending.size, 0); assert.equal(e.stats.expired, 1); assert.equal(e.stats.invalid, 1);
});
