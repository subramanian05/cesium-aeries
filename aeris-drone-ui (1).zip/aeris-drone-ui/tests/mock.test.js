import test from 'node:test';
import assert from 'node:assert/strict';
import { createMockServer } from '../server/mock.js';
import { connectSocket } from '../src/transport.js';
globalThis.location={protocol:'http:'};
test('reference backend implements cluster-to-track subscription and REST contract', async()=>{
 const backend=createMockServer(0);await new Promise(r=>backend.http.once('listening',r));
 const port=backend.http.address().port;let events=[],clusters=[],snapshots=0;
 const stop=connectSocket(`ws://127.0.0.1:${port}/ws/drones`,{subscription:{subscriptionId:'1',lod:'clusters',cellDegrees:10},onEvents:e=>events.push(...e),onClusters:c=>clusters=c,onReset:()=>{events=[];clusters=[];snapshots++;},onStatus:()=>{},onInvalid:()=>{}});
 const until=async f=>{const t=Date.now();while(!f()){if(Date.now()-t>5000)throw Error('Mock timeout');await new Promise(r=>setTimeout(r,20));}};
 try {
  await until(()=>snapshots===1&&clusters.length>0);assert.equal(clusters.reduce((n,c)=>n+c.count,0)+events.length,5000);
  stop.subscribe({subscriptionId:'2',lod:'tracks',maxTracks:10000});await until(()=>snapshots===2&&events.length===5000);assert.equal(clusters.length,0);
  const data=await (await fetch(`http://127.0.0.1:${port}/api/drone-details?provider=SKYSAFE&sourceTrackId=UAS-00001`)).json();assert.equal(data.operator,'Demonstration fleet');
 }finally{stop();backend.close();}
});
