import { defineConfig } from '@playwright/test';
export default defineConfig({
  testDir: './tests/browser', timeout: 45000, use: { baseURL: 'http://127.0.0.1:5173', viewport: {width:1440,height:1100}, launchOptions: { args: ['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] } },
  webServer: [
    {command:'npm run dev -- --strictPort',url:'http://127.0.0.1:5173',reuseExistingServer:!process.env.CI},
    {command:'node server/mock.js',url:'http://127.0.0.1:8080/api/drone-details',reuseExistingServer:!process.env.CI}
  ]
});
