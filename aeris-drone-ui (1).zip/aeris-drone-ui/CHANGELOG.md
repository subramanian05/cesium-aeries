# 2.0.0

- Move WebSocket and demo ingestion to a module Web Worker.
- Add acknowledged batches with bounded pending changes.
- Add eight-sample motion histories, interpolation delay and capped prediction.
- Animate Cesium primitives directly with a 30 FPS target.
- Add TanStack Virtual track grid and TanStack Query reference metadata.
- Add opt-in, debounced viewport subscriptions and reject obsolete responses.
- Add cluster rendering/drill-down and a matching mock backend protocol.
- Preserve plain JSON WebSocket compatibility by default.
- Extend automated test coverage and document Java/Spring integration requirements.
